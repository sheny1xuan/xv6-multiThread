#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/fcntl.h"
#include "kernel/param.h"
#include "user/user.h"

#define NULL 0

void get_new_args(int* argc, char* argv[], char* s) {
    int n = strlen(s);

    for (int i = 0; i < n;) {
        if (s[i] == ' ') {
            i += 1;
            continue;
        }

        int j = i;
        while (j < n && s[j] != ' ') {
            j += 1;
        }

        int slen = j - i;

        argv[*argc] = malloc(slen + 1);
        memmove(argv[*argc], s, slen);
        argv[*argc][slen + 1] = 0;
        *argc += 1;

        i = j + 1;
    }
}

int
main(int argc, char* argv[]) {
    if (argc == 1) {
        mypanic(1, "xargs: use as xargs [command]");
    }
    char buf[512];
    for (;;) {
        memset(buf, 0, sizeof(buf));

        gets(buf, 512);

        // remove \n
        buf[strlen(buf) - 1] = 0;

        int cpid = fork();

        if (cpid == -1) {
            mypanic(1, "xargs: fork error\n");
        }

        if (cpid == 0) {
            int new_argc = argc - 1;
            char* new_argv[MAXARG];
            char new_path[512];

            strcpy(new_path, argv[1]);
            for (int i = 1; i < argc; i++) {
                new_argv[i - 1] = malloc(strlen(argv[i]) + 1);
                strcpy(new_argv[i - 1], argv[i]);
            }

            get_new_args(&new_argc, new_argv, buf);
            new_argv[new_argc] = NULL;

            // for (int i = 0; i < new_argc; i++) {
            //     printf("arg[%d]: %s\n", i, new_argv[i]);
            // }
            exec(new_path, (char**)new_argv);

            exit(0);
        } else {
            if (wait(NULL) != cpid) {
                mypanic(1, "xargs: wait child error\n");
            }
        }
    }
    
    exit(0);
}