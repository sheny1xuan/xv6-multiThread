#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/fcntl.h"
#include "user/user.h"

#include <stdarg.h>

const uint8 END = 255;
void output(uint8 x) {
    printf("prime %d\n", x);
}

void doChild(int* pipefd) {
    close(pipefd[1]);
    uint8 fractor;
    if (read(pipefd[0], &fractor, 1) <= 0) {
        mypanic(1, "Read from pipe error %d \n", fractor);
        exit(1);
    }
    output(fractor);

    uint8 number;
    int childpipe[2];
    if (pipe(childpipe) == -1) {
        mypanic(1, "generate child pipe error\n");
    }
    uint8 forked = 0;
    int cpid;
    while (read(pipefd[0], &number, 1) > 0) {
        if (number % fractor != 0) {
            if (!forked) {
                cpid = fork();

                if (cpid == -1) {
                    mypanic(1, "fork error in child\n");
                }

                if (cpid == 0) {
                    // child 
                    close(pipefd[0]);
                    close(childpipe[1]);
                    doChild(childpipe);
                    exit(0);
                } else {
                    // current;
                    close(childpipe[0]);
                }

                forked = 1;
            }

            write(childpipe[1], &number, 1);
        }
    }

    if (forked) {
        close(childpipe[1]);
        if (cpid != wait(0)) {
            mypanic(1, "primes: wait pid is not equal child.\n");
        }
    }
}

int
main(int argc, char const *argv[])
{
    // Every process have its fractor, init is 2.
    uint8 fractor = 2;
    int pipefd[2];

    if (pipe(pipefd) == -1) {
        mypanic(1, "generate pip error\n");
    }
    int cpid = fork();

    if (cpid == -1) {
        mypanic(1, "fork error \n");
    }
    if (cpid == 0) {
        // child
        doChild(pipefd);
        exit(0);
    } else {
        // parent
        close(pipefd[0]);
        output(2);
        for (uint8 i = 3; i <= 35; i++) {
            if (i % fractor != 0) {
                if (write(pipefd[1], &i, 1) == -1) {
                    mypanic(1, "Write to pipe error %d \n", i);
                    exit(1);
                }
            }
        }

        close(pipefd[1]);
        // wait child
        if (cpid != wait(0)) {
            mypanic(1, "primes: wait pid is not equal child.\n");
        }
        exit(0);
    }
    return 0;
}
