#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/fcntl.h"
#include "user/user.h"

char child_buf[8];
char parent_buf[8];

int
main(int argc, char* argv[]) {
    
    int fds[2];
    if (pipe(fds) == -1) {
        mypanic(1, "genereate pip error \n");
    }

    int cpid = fork();
    if (cpid == -1) {
        mypanic(1, "fork error \n");
    }

    if (cpid == 0) {
        if (read(fds[0], &child_buf, 1) > 0) {
            fprintf(1, "%d: received ping\n", getpid());
        }
        write(fds[1], &child_buf, 1);
    } else {
        parent_buf[0] = 'a';
        if (write(fds[1], &parent_buf, 1) == -1) {
            mypanic(1, "parent write error \n");
        }
        read(fds[0], &parent_buf, 1);
        fprintf(1, "%d: received pong\n", getpid());
    }

    exit(0);
}