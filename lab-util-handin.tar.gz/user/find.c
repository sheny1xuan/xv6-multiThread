#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"

void find(char* path, char* target) {
    char *p;
    int fd;
    char buf[512];
    struct dirent de;
    struct stat st;

    if((fd = open(path, 0)) < 0) {
        mypanic(1, "find: can't open the path: %s \n", path);
    }

    if(fstat(fd, &st) < 0) {
        close(fd);
        mypanic(1, "find: cannot stat %s\n", path);
    }

    switch (st.type) {
        case T_DIR:
            // Prepare dir name.
            if(strlen(path) + 1 + DIRSIZ + 1 > 512){
                printf("find: path too long\n");
                break;
            }
            strcpy(buf, path);
            p = buf+strlen(buf);
            *p++ = '/';
            // read dir
            while(read(fd, &de, sizeof(de)) == sizeof(de)){
                if(de.inum == 0)
                    continue;
                if (strcmp(de.name, "..") == 0 || strcmp(de.name, ".") == 0) {
                    // printf("get . or ..\n");
                    continue;
                }
                memmove(p, de.name, DIRSIZ);
                p[DIRSIZ] = 0;
                // printf("File: %s\n", buf);
                if(stat(buf, &st) < 0){
                    printf("find: cannot stat path: %s, filename: %s\n", buf, de.name);
                    continue;
                }

                // same dir or same file: print!
                if (strcmp(de.name, target) == 0) {
                    printf("%s\n", buf);
                }
                find(buf, target);
            }
            break;
        case T_FILE:
        case T_DEVICE:
            break;
        default:
            mypanic(1, "find: don't have this file type in xv6 %s \n", path);
    }
    // must close fd.
    close(fd);
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        mypanic(1, "Please use with command -> find path target.\n");
    }

    char* path = argv[1];
    char* target = argv[2];
    // printf("find path: %s, target: %s \n", path, target);
    find(path, target);
    exit(0);
}